﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;

public class playerInput : MonoBehaviour {

    public InputField userInputField;
    // Use this for initialization
    void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public void storeUserNamer()
    {
        statsManager.userName = userInputField.text;
        StartCoroutine(addText("Hi " + statsManager.userName + "It's nice to meet you."));
    }

    private IEnumerator addText(string v)
    {
        throw new NotImplementedException();
    }
}
