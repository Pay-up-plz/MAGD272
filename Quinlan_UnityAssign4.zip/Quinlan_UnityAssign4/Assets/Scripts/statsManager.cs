﻿using UnityEngine;
using System.Collections;

public class statsManager{

	public static int lives;
	public static int moves;
	public static float health;
    public static int charisma;
	public static string userName;
	public static float questionIndex;
	public static float answerIndex;
}
